# KPI — Kunduzgi animatsion fon

Mavjud KPI dasturi uchun yangilanish, to‘liq dastur emas.

1. KPI qora oynasini yoping.
2. ZIPni alohida papkaga to‘liq oching (Extract All / Извлечь всё).
3. INSTALL-GALAXY.bat ni ishga tushiring.
4. Mavjud dasturdagi start-native.bat ni tanlang.
5. TAYYOR yozuvidan keyin start-native.bat ni qayta oching.
6. Brauzerda Ctrl+F5 bosing, yuqoridagi quyosh tugmasi bilan kunduzgi rejimga o‘ting.

Och moviy osmon, iliq quyosh nuri va sekin harakatlanuvchi bulutli fon.
Harakatni kamaytirish sozlamasi yoqilsa animatsiya to‘xtaydi.
Tungi galaktika ko‘rinishi saqlanadi; tashqi rasm yoki CDN kerak emas.

Faqat uchta interfeys fayli yangilanadi. Eski fayllar va standart SQLite baza
runtime/galaxy-backup-* papkasiga zaxiralanadi. Baza, parollar, hujjatlar
va HEMIS sozlamalari almashtirilmaydi.

ZIP yaxlitligi va fayllar SHA256 summalari tekshirildi. Animatsiya brauzerda
alohida maketda tekshirildi. Windows BAT o‘rnatgichi ushbu Linux muhitida
bevosita bajarilmagan, to‘liq PHP ilovasi ishga tushirib tekshirilmagan.
